package vector;

import java.util.List;
import java.util.Vector;

public class AddingVector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Double> arr=new Vector<>();
		 arr.add(10.25);
		 arr.add(20.25);
		 arr.add(30.25);
		 arr.add(40.25);
		 arr.add(50.25);
		 
		 System.out.println(arr);
		 System.out.println(arr.size());
		 
		 arr.add(10.5);
		 arr.add(20.25);
		 arr.add(30.25);
		 arr.add(40.25);
		 arr.add(50.25);
		 
		 System.out.println(arr);
		 System.out.println(arr.size());
		 

		 System.out.println(arr.contains(10.5));
		

	}

}
