package vector;

import java.util.Vector;
import java.util.List;

public class VectorToArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> colors = new Vector<>();
		colors.add("Red");
		colors.add("Blue");
		colors.add("Yellow");

		String colorArray[] = new String[colors.size()];

		System.out.println("Fruits -->  Vector to Array");
		for (int i = 0; i < colors.size(); i++) {
			colorArray[i] = colors.get(i);
			System.out.println(colorArray[i]);
		}
		System.out.println("Fruits -->  Array to Vector");
		List<String> list = new Vector<>();
		for (int i = 0; i < colorArray.length; i++) {

			list.add(colorArray[i]);
			System.out.println(list.get(i));
		}


	}

}
