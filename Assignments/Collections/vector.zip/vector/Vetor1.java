package vector;

import java.util.List;
import java.util.Vector;

public class Vetor1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> arr=new Vector<>();
		 arr.add(10);
		 arr.add(20);
		 arr.add(30);
		 arr.add(40);
		 arr.add(50);
		 
		 System.out.println(arr.get(2));
		 System.out.println(arr);
			

	}

}
