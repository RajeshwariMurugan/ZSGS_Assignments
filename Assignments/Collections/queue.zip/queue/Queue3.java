package queue;

import java.util.LinkedList;
import java.util.Queue;

class Job {
	String jobName;
	int processingTime;
	int waitingTime;
	int turnaroundTime;

	public Job(String jobName, int processingTime) {
		this.jobName = jobName;
		this.processingTime = processingTime;
		this.waitingTime = 0;
		this.turnaroundTime = 0;
	}

	public void calculateTimes(int currentTime) {
		waitingTime = currentTime;
		turnaroundTime = waitingTime + processingTime;
	}

	@Override
	public String toString() {
		return "Job{" + "jobName=" + jobName + " processingTime=" + processingTime + ", waitingTime="
				+ waitingTime + ", turnaroundTime=" + turnaroundTime + '}';
	}
}

public class Queue3 {
	public static void main(String[] args) {

		Queue<Job> jobQueue = new LinkedList<>();

		jobQueue.add(new Job("Job1", 3));
		jobQueue.add(new Job("Job2", 5));
		jobQueue.add(new Job("Job3", 2));
		jobQueue.add(new Job("Job4", 4));

		int currentTime = 0;
		while (!jobQueue.isEmpty()) {
			Job job = jobQueue.poll();
			job.calculateTimes(currentTime);
			System.out.println(job);

			currentTime += job.processingTime;
		}
	}
}
