package queue;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class Queue1 {
	public static void main(String[] args) {

		Queue<String> queue = new LinkedList<>();
		queue.add("apple");
		queue.add("banana");
		queue.add("cherry");
		queue.add("date");

		Iterator<String> iterator = queue.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
}
