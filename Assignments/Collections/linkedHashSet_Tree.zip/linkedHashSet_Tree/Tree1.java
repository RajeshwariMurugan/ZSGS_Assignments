package linkedHashSet_Tree;

import java.util.TreeSet;

public class Tree1 {
	public static void main(String[] args) {

		TreeSet<Integer> treeSet = new TreeSet<>();

		treeSet.add(50);
		treeSet.add(30);
		treeSet.add(20);
		treeSet.add(10);
		treeSet.add(40);

		System.out.println("TreeSet elements: " + treeSet);
	}
}
