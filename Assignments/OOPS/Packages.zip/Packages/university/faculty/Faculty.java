package Packages.university.faculty;

import java.util.List;

import Packages.university.courses.Course;

public class Faculty {
	private String name;
	private int facultyId;
	private List<Course> taughtCourses;

	public Faculty(String name, int facultyId, List<Course> taughtCourses) {
		this.name = name;
		this.facultyId = facultyId;
		this.taughtCourses = taughtCourses;
	}

	public String getName() {
		return name;
	}

	public int getFacultyId() {
		return facultyId;
	}

	public List<Course> getTaughtCourses() {
		return taughtCourses;
	}

	public void addCourse(Course course) {
		taughtCourses.add(course);
	}

	public void removeCourse(Course course) {
		taughtCourses.remove(course);
	}

}
