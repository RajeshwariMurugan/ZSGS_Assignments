package Packages.university;

import university.students.Student;
import university.courses.Course;
import university.faculty.Faculty;

import java.util.ArrayList;
import java.util.List;

public class University {
	public static void main(String[] args) {

		Course course1 = new Course("Computer Science 101", "CS101", 4);
		Course course2 = new Course("Physics 101", "P1830", 3);

		List<Course> subjects = new ArrayList<>();
		subjects.add(course1);
		Faculty faculty1 = new Faculty("Dr. Rabinson Jebas", 1, subjects);

		List<Course> studentCourses = new ArrayList<>();
		studentCourses.add(course1);
		Student student1 = new Student("Rajii", 4, studentCourses);

		faculty1.addCourse(course2);

		System.out.println(student1);
		System.out.println(faculty1);
	}
}
