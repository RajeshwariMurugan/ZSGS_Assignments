package Packages.university.students;

import java.util.List;
import university.courses.Course;

public class Student {
	private String name;
	private int studentId;
	private List<Course> enrolledCourses;

	public Student(String name, int studentId, List<Course> enrolledCourses) {
		this.name = name;
		this.studentId = studentId;
		this.enrolledCourses = enrolledCourses;
	}

	public String getName() {
		return name;
	}

	public int getStudentId() {
		return studentId;
	}

	public List<Course> getEnrolledCourses() {
		return enrolledCourses;
	}

	public void enrollInCourse(Course course) {
		enrolledCourses.add(course);
	}

}
