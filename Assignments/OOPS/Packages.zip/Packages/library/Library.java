package Packages.library;

import Packages.library.books.Book;
import Packages.library.members.Member;
import Packages.library.transactions.Transaction;

public class Library {
	public static void main(String[] args) {
		
		Book book1 = new Book("Ponniyin Selvan", "Kalki");
		Book book2 = new Book("Paanjali Sabatham", " Bharathiyar");

		Member member1 = new Member("Gokila", 1);
		Member member2 = new Member("Banu", 2);

	
		Transaction transaction1 = new Transaction(book1, member1, "borrow");
		transaction1.processTransaction();

		Transaction transaction2 = new Transaction(book2, member2, "borrow");
		transaction2.processTransaction();

		// Already Gokila borrow this book now banu wants this book... So unavailable
		// this book
		Transaction transaction4 = new Transaction(book1, member2, "borrow");
		transaction4.processTransaction();
	}
}
