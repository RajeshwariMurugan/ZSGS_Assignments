package Packages.library.members;

public class Member {
	private String name;
	private int memberId;
	private int borrowedBooks;

	public Member(String name, int memberId) {
		this.name = name;
		this.memberId = memberId;
		this.borrowedBooks = 0;
	}

	public int getMemberId() {
		return memberId;
	}

	public int getBorrowedBooks() {
		return borrowedBooks;
	}

	public void borrowBook() {
		borrowedBooks++;
	}

	public void returnBook() {
		borrowedBooks--;
	}

	public String getName() {
		return name;
	}

}
