package Packages.library.transactions;

import Packages.library.books.Book;
import Packages.library.members.Member;

public class Transaction {
	private Book book;
	private Member member;
	private String borrowReturn; // Borrow or Return

	public Transaction(Book book, Member member, String borrowReturn) {
		this.book = book;
		this.member = member;
		this.borrowReturn = borrowReturn;
	}

	public void processTransaction() {
		if (borrowReturn.equalsIgnoreCase("borrow")) {
			if (book.isAvailable()) {
				book.setAvailable(false);
				member.borrowBook();
				System.out.println(member.getName() + " borrowed " + book.getTitle());
			} else {
				System.out.println("Book is not available.");
			}
		} else if (borrowReturn.equalsIgnoreCase("return")) {
			if (!book.isAvailable()) {
				book.setAvailable(true);
				member.returnBook();
				System.out.println(member.getName() + " returned " + book.getTitle());
			} else {
				System.out.println("Book is already available.");
			}
		} else {
			System.out.println("Invalid transaction type.");
		}
	}

}
