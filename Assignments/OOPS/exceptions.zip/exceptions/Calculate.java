package exceptions;

public class Calculate {

	public String calculate(int operand1, int operand2, String operation) {

		if (operation == null) {
			throw new IllegalArgumentException("Operation cannot be null");
		}
		if (operation.isEmpty()) {
			throw new IllegalArgumentException("Operation cannot be empty");
		}
		try {
			switch (operation) {
			case "-":
				return operand1 + " + " + operand2 + " = " + (operand1 - operand2);
			case "/":
				return operand1 + " / " + operand2 + " = " + (operand1 / operand2);
			case "*":
				return operand1 + " * " + operand2 + " = " + (operand1 * operand2);
			case "+":
				return operand1 + " + " + operand2 + " = " + (operand1 + operand2);
			default:
				throw new IllegalOperationException(String.format("Operation does not exist", operation));
			}
		} catch (ArithmeticException e) {
			throw new IllegalOperationException("Division by zero is not allowed", e);
		}

	}
	
	public static void main(String args[]) {
		Calculate calculates=new Calculate();
		calculates.calculate(12, 0, "B");
	}
}

class IllegalOperationException extends RuntimeException {
	public IllegalOperationException(String errorMessage) {
		super(errorMessage);
	}

	IllegalOperationException(String errorMessage, Throwable cause) {
		super(errorMessage, cause);
	}
}
